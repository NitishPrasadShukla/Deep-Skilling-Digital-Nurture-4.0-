package com.akshita.springweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountryDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
