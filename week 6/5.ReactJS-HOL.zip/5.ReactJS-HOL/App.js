import React from 'react';
import './App.css';
import CohortDetails from './CohortDetails';

function App() {
  return (
    <div className="App">
      <CohortDetails name="React Cohort" trainer="Akshita" status="ongoing" />
    </div>
  );
}

export default App;
