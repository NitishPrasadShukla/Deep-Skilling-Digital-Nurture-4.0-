package com.library.repository;

public class BookRepository {
    public String getBookInfo() {
        return "Spring Framework Essentials - Cognizant Edition";
    }
}
