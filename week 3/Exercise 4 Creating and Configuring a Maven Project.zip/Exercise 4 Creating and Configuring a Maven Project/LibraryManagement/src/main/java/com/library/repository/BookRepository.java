package com.library.repository;

public class BookRepository {
    public String getBookInfo() {
        return "Mastering Spring Boot 3 - Cognizant Tech Track";
    }

    public String getCourseDuration() {
        return "Duration: 6 Weeks (Online)";
    }

    public String getTrainerName() {
        return "Trainer: Mr. Ramesh K, Senior Architect - Cognizant";
    }
}
