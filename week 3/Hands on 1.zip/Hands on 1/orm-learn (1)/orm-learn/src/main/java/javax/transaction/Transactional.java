package javax.transaction;

public class Transactional {

}
