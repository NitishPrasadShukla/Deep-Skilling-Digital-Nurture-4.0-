package documents;

public class PdfDocument implements Document {
    public void open() {
        System.out.println("PDF Document opened.");
    }
}
