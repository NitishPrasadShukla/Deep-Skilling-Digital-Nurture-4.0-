package documents;

public class WordDocument implements Document {
    public void open() {
        System.out.println("Word Document opened.");
    }
}
